import { OtpForm } from '@/components/otp-form';

export default function VerifyOtpPage() {
  return <OtpForm />;
}
