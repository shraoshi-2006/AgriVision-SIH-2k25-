import { MobileVerificationForm } from '@/components/mobile-verification-form';

export default function MobileVerificationPage() {
  return <MobileVerificationForm />;
}